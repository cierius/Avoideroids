Avoideroids V0.9.2 - The premiere asteroid avoiding game!!! (Prototype)

Instructions (cuz they aren't shown in-game):
 - LMB: ship toward mouse


Armor is gained every 250 score.

Score multiplier goes up 1x every 7.5 seconds to a max of 10x

Invuln lasts 5 seconds.


Planned Updates:
 - More asteroid sprites
 - Sounds / Music

Possible Updates:
 - Main Menu
 - Death Menu / Recap Screen
 - Different difficulties


If you've got any suggestions let me know!!!

Yuh boi, 
  Kanin (Cierius)