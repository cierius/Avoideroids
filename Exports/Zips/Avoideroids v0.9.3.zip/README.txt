Avoideroids V0.9.3 - The premiere asteroid avoiding game!!! (Prototype)

Instructions (cuz they aren't shown in-game):
 - LMB: ship toward mouse
 - ESC: un/pause game (There is a bug with the pause menu screen when fullscreen.)
 - F: un/fullscreen


Armor is gained every 100 score.

Score multiplier goes up 1x every 7.5 seconds to a max of 10x

Invuln lasts 5 seconds.


Planned Updates:
 - Different difficulties
 - Sounds / Music

Possible Updates:
 - Death Menu / Recap Screen
 


If you've got any suggestions let me know!!!

Yuh boi, 
  Kanin (Cierius)